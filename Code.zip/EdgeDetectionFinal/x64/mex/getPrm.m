function prm = getPrm()	
    prm.removeEpsilon = 0.08;
	prm.splitPoints = 0;
    prm.maxTurn = 38;
	prm.minContrast = 8;
    prm.nmsFact = 0.76;
    
    prm.linearStrech = true;
    prm.addShift = true;
end