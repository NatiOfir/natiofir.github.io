function prm = getPrm2()	
    prm.removeEpsilon = 0.22;
	prm.splitPoints = 0;
    prm.maxTurn = 42;
	prm.minContrast = 9;
    prm.nmsFact = 0.65;
    
    prm.linearStrech = true;
    prm.addShift = true;
end